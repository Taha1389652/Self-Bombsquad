from bascenev1lib.actor.spazappearance import Appearance

# Spaz #######################################
t = Appearance('steve')
t.color_texture = 'steveColor'
t.color_mask_texture = 'steveColorMask'
t.icon_texture = 'steveIconColor'
t.icon_mask_texture = 'steveIconColorMask'
t.head_mesh = 'steveHead'
t.torso_mesh = 'steveTorso'
t.pelvis_mesh = 'none'
t.upper_arm_mesh = 'steveUpperArm'
t.forearm_mesh = 'steveForeArm'
t.hand_mesh = 'none'
t.upper_leg_mesh = 'steveUpperLeg'
t.lower_leg_mesh = 'steveLowerLeg'
t.toes_mesh = 'none'
t.death_sounds = ['steveDeath']
steve_hits = ['steveDamage']
t.impact_sounds = steve_hits
t.style = 'agent'